alert("Gracias por ingresar a nuestra formulario");






function nombre(nombre){

}



function validateEmailAddress(email) {
	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	return re.test(email);
}
result="";
function validate() {
	$("#result").text("");
	var emailaddress = $("#email").val();
	if (validateEmailAddress(emailaddress)) {
		$("#result").text(emailaddress + " es valido :)");	
		$("#result").css("color", "green");
	} else {
		$("#result").text(emailaddress + " No es correcto");
		$("#result").css("color", "red");
	}
	return false;
}
	$("#validate").bind("click", validate);	

let d = new Date();
document.body.innerHTML = "<h1>Time right now is:  " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds()"</h1>"
